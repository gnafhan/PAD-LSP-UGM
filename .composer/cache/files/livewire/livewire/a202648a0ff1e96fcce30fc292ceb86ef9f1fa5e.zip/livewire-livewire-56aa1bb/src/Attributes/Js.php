<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportJsEvaluation\BaseJs;

#[\Attribute]
class Js extends BaseJs
{
    //
}
