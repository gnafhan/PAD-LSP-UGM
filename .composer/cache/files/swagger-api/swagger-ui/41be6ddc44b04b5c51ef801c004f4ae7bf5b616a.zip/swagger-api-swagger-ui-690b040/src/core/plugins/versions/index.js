/**
 * @prettier
 */
import afterLoad from "./after-load.js"

const VersionsPlugin = () => ({
  afterLoad,
})

export default VersionsPlugin
