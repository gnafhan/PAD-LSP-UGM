/**
 * @prettier
 */
const int32Generator = () => 0

export default int32Generator
