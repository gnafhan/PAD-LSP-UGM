<?php

namespace Laravel\Fortify\Events;

class TwoFactorAuthenticationFailed extends TwoFactorAuthenticationEvent
{
    //
}
