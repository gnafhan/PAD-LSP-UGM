<?php

namespace Laravel\Jetstream\Contracts;

/**
 * @method \Illuminate\Database\Eloquent\Model create(\Illuminate\Foundation\Auth\User $user, array $input)
 */
interface CreatesTeams
{
    //
}
